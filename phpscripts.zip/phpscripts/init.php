<?php
	require_once('functions.php');
	require_once('read.php');
	require_once('login.php');
	require_once('sessions.php');
	require_once('user.php');
	require_once('recMovie.php');
	//require_once('single_edit_form.php');

?>